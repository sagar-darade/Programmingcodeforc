
#include<stdio.h>       // REquired for printf and scanf

int CountEvenDigits(int);

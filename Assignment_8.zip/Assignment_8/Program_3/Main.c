
/*
Problem Statement:Accpet number from user and find factorial number. 
*/

#include"Header.h"

int main()
{
	int iValue = 0,iRet = 0;
	
	printf("Enter number\n");
	scanf("%d",&iValue);
	
	iRet = Factorial(iValue);
	printf("Factorial of number is : %d",iRet);
 
  return 0;
} 
#include"Header.h"

////////////////////////////////////////////
//	Function Name:	Factorial
//	Input:			integr
//	Output:			integr
//	Description:	it is used to factorial number
//	Author:			Sagar Darade
//	Date:			06-08-2020
//
////////////////////////////////////////////////

int Factorial(iNo)
{
	int iCnt=0;
	int iAns=1;
	
	for(iCnt=1;iCnt<=iNo;iCnt++)
	{
		iAns=iAns*iCnt;
	}
	
  return iAns;	
}
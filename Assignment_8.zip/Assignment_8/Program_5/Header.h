#include<stdio.h>
void  TableRev(int);
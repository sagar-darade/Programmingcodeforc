/*
Problem Statement:-Accept single digit number from user and print it into word
*/

#include"Header.h"
 int main()
 {
	 int iValue = 0;
	 
	 printf("Enter number\n");
	 scanf("%d",&iValue);
	 
	 Number(iValue);
	 
	return 0;
 }  
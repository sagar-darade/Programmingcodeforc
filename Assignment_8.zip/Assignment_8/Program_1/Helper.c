#include"Header.h"

////////////////////////////////////////////
//	Function Name:	 Number
//	Input:			integr
//	Output:			integr
//	Description:	it is used to less than 50 print Samll and if it is greater than 50 print Meadium and grater than 100 the print Large 
//	Author:			Sagar Darade
//	Date:			06-08-2020
//
////////////////////////////////////////////////

void  Number(iNo)
{
		
	if(iNo<0)
	{
		iNo=-iNo;
	}
	if(iNo<50)
	{
		printf("Samll");
	}
	else if(iNo>50)
	{
	    printf("Meadium");
	}
	else (iNo>100)
	{
		printf("Large");
	}
}
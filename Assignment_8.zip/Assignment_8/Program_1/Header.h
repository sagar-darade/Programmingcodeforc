#include<stdio.h>
void  Number(int);

/*
Problem Statement:Accept number from user and if number is less than 50then print small ,if it is greater than 50 and less than 100 then print medium, if it is
greater than 100 then print large. 
 */

#include"Header.h"

int main()
{
	int iValue = 0;
	
	printf("Enter number\t");
	scanf("%d",&iValue);
	
	 Number(iValue);
 
  return 0;
} 
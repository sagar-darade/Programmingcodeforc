#include"Header.h"

////////////////////////////////////////////
//	Function Name:	Table
//	Input:			integr
//	Output:			integr
//	Description:	it is used to table
//	Author:			Sagar Darade
//	Date:			06-08-2020
//
////////////////////////////////////////////////

void Table(iNo)
{
	int iAns=0;
	int iCnt=1;
	
	if(iNo<0)
	{
		iNo=-iNo;
	}
	for(iCnt=1;iCnt<=10;iCnt++)
	{
		
		iAns=iCnt*iNo;
		printf("%d\n",iAns);
	}	
}
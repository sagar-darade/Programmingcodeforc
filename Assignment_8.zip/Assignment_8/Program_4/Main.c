
/*
Problem Statement:Accpet number from user and display its table.
 */

#include"Header.h"

int main()
{
	int iValue = 0;
	
	printf("Enter number\t");
	scanf("%d",&iValue);
	
	Table(iValue);
 
  return 0;
} 
#include<stdio.h>
#include<string.h>

void StrCatX(char *src, char *dest)
{
	while(*src!= '\0')
	{
	 src++;
	}
	while(*dest!= '\0')
	{
			*src=*dest;
			src++;
			dest++;
	}
	*dest= '/0'; 
}
int main()
{
 char arr[30] = "Marvellous multi OS";
 char brr[30]="Logic Building";

 StrCatX(arr,brr);
 
 printf(" %s", arr); //

 return 0;
}
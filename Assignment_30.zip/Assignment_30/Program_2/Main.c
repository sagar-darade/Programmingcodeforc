#include<stdio.h>
#include<string.h>

void StrNcpyX(char *src, char *dest,int icnt)
{
	while((*src != '\0') && (icnt != 0) ) 
	{
		*dest=*src;
			src++;
			dest++;
			icnt--;
	}
	return dest;
}
int main()
{
 char arr[30] = "Marvellous Multi OS";
 char brr[30]; // Empty string

 StrNcpyX(arr,brr,10);
 
 printf("%s",brr); // Marvellous Multi OS

 return 0;
}
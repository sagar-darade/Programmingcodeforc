#include<stdio.h>
#include<string.h>

void Strcpycap(char *src, char *dest)
{
	while(*src != '\0')
	{
		if((*src >= 'a') && (*src<='z')) 
		{
			*dest=*src;
			dest++;
		}
			src++;		
	}
	return dest;
}
int main()
{
 char arr[30] = "Marvellous multi OS";
 char brr[30]; // Empty string

 Strcpycap(arr,brr);
 
 printf(" %s",brr); //

 return 0;
}


#include<stdio.h>

 int FirstChar(char str[],char ch)

{
	int i=0;
	int iCnt=0;

	while(str[i]!='\0')
	{
		if(str[i]==ch)
		{
			break;
		}
		i++;
	}
	if(str[i]==ch)
	{
		return i;
	}
	else
	{
		return -1;
	}
}


int main()
{
 char arr[20];
 char cValue='\0';
 int bRet =0;

 printf("Enter string");
 scanf("%[^’\n’]s",arr);

 printf("Enter the character");

 scanf(" %c",&cValue);

 bRet = FirstChar(arr,cValue);

 if(bRet == -1)
    {
        printf("There is no such character \n");
    }
    else
    {
        printf("First occurance of character is  : %d\n",bRet);
    } 
 return 0;
} 

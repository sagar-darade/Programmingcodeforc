

#include<stdio.h>

 int FirstChar(char str[],char ch)

{
	int i=0;
	int iCnt=-1;

	for(i = 0; str[i] != '\0'; i++)
	{
		if(str[i] == ch)
		{
			iCnt = i;
		}  
	}
	return iCnt;
}


int main()
{
 char arr[20];
 char cValue='\0';
 int bRet =0;

 printf("Enter string");
 scanf("%[^’\n’]s",arr);

 printf("Enter the character");

 scanf(" %c",&cValue);

 bRet = FirstChar(arr,cValue);

 if(bRet == -1)
    {
        printf("There is no such character \n");
    }
    else
    {
        printf("Last occurance of character is  : %d\n",bRet);
    } 
 return 0;
} 

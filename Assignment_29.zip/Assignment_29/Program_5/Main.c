#include<stdio.h>

 int Revstr(char str[])
{
 int iStart = 0;     //      0   7   0       5       1
    int iEnd = 0;       //      0   7   70      705     7051
    char temp='\0';
	//int i=0;

if(str==NULL)
{
	return;
}
while(str[iEnd]!='\0')
    {
		iEnd++;
    }
	iEnd--;
	while(iStart<iEnd)
	{
		temp = str[iStart];
        str[iStart]=str[iEnd];
		str[iEnd]=temp;
		iStart++;
		iEnd--;
	}	
}


int main()
{
 char arr[20];
 char cValue='\0';
 //int bRet =0;

 printf("Enter string");
 scanf("%[^’\n’]s",arr);


 Revstr(arr);

 printf("Modified string is %s\n",arr);
    
 return 0;
} 

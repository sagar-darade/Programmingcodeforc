

#include<stdio.h>

 CountChar(char str[],char ch)

{
	int i=0;
	int count=0;
	
	 while(*str!='\0')
	 {		 	
			if(*str==ch)
			{
			 count++;
			}
			
		 
		 str++;
	 }
	return count++;
}


int main()
{
 char arr[20];
 char cValue='\0';
 int bRet =0;

 printf("Enter string");
 scanf("%[^’\n’]s",arr);

 printf("Enter the character");

 scanf(" %c",&cValue);

 bRet = CountChar(arr,cValue);

 
 printf("%d\n",bRet);
 
 return 0;
} 

/*#include<stdio.h>
typedef int BOOL;

#define TRUE 1
#define FALSE 0

BOOL ChkChar(char str[],char ch)

{
	int i=0;
	int count=0;
	/*while(str[i]!='\0')
	 {
		if ((str[i]>= 'a' && str[i] <= 'z') || (str[i] >= 'A' && str[i] <= 'Z'))
		
			if (str[i] == ch)
			{
				count++;
			}
			i++;	
	 }
	 while(*str!='\0')
	 {
		
		 	
			if(*str==ch)
			{
					// if ((*str>= 'a' && *str <= 'z') || (*str >= 'A' && *str <= 'Z'))
			 count++;
			}
			
		 
		 str++;
	 }
	return count++;
}


int main()
{
 char arr[20];
 char cValue='\0';
 int bRet = FALSE;

 printf("Enter string");
 scanf("%[^’\n’]s",arr);

 printf("Enter the character");

 scanf(" %c",&cValue);

 bRet = ChkChar(arr,cValue);

 
 printf("%d\n",bRet);
 
 return 0;
} 


*/
#include<stdio.h> 

#define TRUE 1
#define FALSE 0
typedef int BOOL;


BOOL Chkchar(char *str ,char ch)
{
	int count=0;
   while(*str!='\0')
	 {
		
		 	
			if(*str==ch)
			{
				return 1;
//			 count++;
			}
			else {
				return 0;
			}
			str++;
	 }

}

int main()
{
	 char cValue = '\0';
	 BOOL bRet = FALSE;
	 char arr[20];
	 
	 printf("Enter string");
	 scanf("%[^’\n’]s",arr);
	 
	 printf("Enter the character :\t");
	 scanf(" %c",&cValue);
	 
	 bRet = Chkchar(arr,cValue);
	 
	 if(bRet == TRUE)
	 {
		printf("Character found");
	 }
	 else
	 {
		printf("Character not found"); 
	 }

 return 0;
}
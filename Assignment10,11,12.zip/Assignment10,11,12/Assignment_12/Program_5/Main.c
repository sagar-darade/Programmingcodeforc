

/*
Problem statement :
Accpet no from user returns difference between Even factorial and odd factorial of given number. 

 */

#include<stdio.h>

int FactorialDiff(int iNo) 
{
	int iCnt=0;
	int jCnt=0;
    int iAns=1;
	int iDif=0;
	int iFact=1;
	
	if(iNo<0)
	{
		iNo=-iNo;
	}
	
	for( iCnt = 1 ; iCnt <=iNo ; iCnt++ )
    {
		if((iCnt%2)!=0)
		{	
			iAns=iAns*iCnt;
			//printf("%d\n",iAns);
		}
    }	
	for(jCnt = 1 ; jCnt <=iNo ; jCnt++)
	{
	
		if(jCnt%2==0)
		{
			
			iFact=iFact*jCnt;
			//printf("%d\n",iFact);
		}
	}
	iDif=iFact-iAns;
	//printf("%d\n",iDif);
    
	return iDif;
}

int main()
{
   int iValue = 0;
   int iRet = 0; 
    
    printf("Enter number: \n");
    scanf("%d",&iValue);
    
    iRet=FactorialDiff(iValue) ;
    
    printf("Multiplication Of Evevn Factor: %d\n",iRet);
    
    return 0;   // return to OS

}
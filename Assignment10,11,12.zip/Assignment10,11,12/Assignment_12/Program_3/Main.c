/*
Problem statement :
 Acceptno from user  program to find even factorial of given number. 


#include<stdio.h>

int EvenFactorial(int iNo) 
{
	int iCnt=0;
    int iAns=1;
	
	for( iCnt = 1 ; iCnt <iNo ; iCnt++ )
    {
		if((iCnt%2)==0)
		{
			//printf("%d",iCnt);
			
			iAns=iAns*iCnt;
			
		}
    }
    return iAns;
}

int main()
{
   int iValue = 0;
   int iRet = 0; 
    
    printf("Enter number: \n");
    scanf("%d",&iValue);
    
    iRet=EvenFactorial(iValue) ;
    
    printf("Multiplication Of Evevn Factor: %d\n",iRet);
    
    return 0;   // return to OS
}











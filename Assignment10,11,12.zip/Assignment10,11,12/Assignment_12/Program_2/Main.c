/*
Problem statement : Accept amount in US dollar and return its corresponding value in Indian currency.
Consider 1$ as 70 rupees. 
 */

#include<stdio.h>

int DollarToINR(int iNo) 
{
    int iAns;
	int iUSD=70;
	
		if(iNo<=0)
		{
			iNo=-iNo;
		}
		iAns = iNo*iUSD;
    
    return iAns;
}

int main()
{
   int iValue = 0;
   int iRet = 0; 
    
    printf("Enter number USD : \n");
    scanf("%d",&iValue);
    
    iRet=DollarToINR(iValue) ;
    
    printf("Value in INR is: %d\n",iRet);
    
    return 0;   // return to OS
}











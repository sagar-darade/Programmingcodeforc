
/*
Problem Statement:-Write a program which accept number from user and display below pattern. */
#include<stdio.h>
void display(int iNo)
{
	int iCnt;
	int jCnt;

	if(iNo<0)
	{
		iNo=-iNo;
	}

	for(iCnt=1;iCnt<=iNo;iCnt++)
	{
		printf("*\t",iNo);
	}
	for(jCnt=1;jCnt<=iNo;jCnt++)
	{
		printf("#\t",iNo);
	}
}

int main()
{
	int iValue;
	
	printf("Enter number:");
	scanf("%d",&iValue);
	
	display(iValue);

	return 0;
}
/*
Problem statement :	Accpet no from userand  odd factorial of given number. 
 
 */

#include<stdio.h>

int OddFactorial(int iNo) 
{
	int iCnt=0;
    int iAns=1;
	
	if(iNo<0)
	{
		iNo=-iNo;
	}
	
	for( iCnt = 1 ; iCnt <=iNo ; iCnt++ )
    {
		if((iCnt%2)!=0)
		{
			//printf("%d",iCnt);
			
			iAns=iAns*iCnt;
			
		}
    }
    return iAns;
}

int main()
{
   int iValue = 0;
   int iRet = 0; 
    
    printf("Enter number: \n");
    scanf("%d",&iValue);
    
    iRet=OddFactorial(iValue) ;
    
    printf("Multiplication Of Evevn Factor: %d\n",iRet);
    
    return 0;   // return to OS
}

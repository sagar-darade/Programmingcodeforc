/*
Problem statement :11.3
  Accept range from user and return addition of all even
numbers in between that range. (Range should contains positive numbers only) 
 Input : 1278   Output : 0
 Input : 45228   Output : 2
 Input : 1078   Output : 0
 Input : 22222   Output : 0
 Input : 5379   Output : 1

 */

#include<stdio.h>



int RangeSumEven(int iStart , int iEnd) {
    
	int iCnt = 0;
	int iSum=0;
	
	
			if(iStart>iEnd)
				{
					
					//printf("Invalid Range");
					//break;
				}
   
    for(iCnt=iStart;iCnt<=iEnd;iCnt++)
	{
		
		if(iCnt%2==0)
		{
			iSum=iSum+iCnt;
			
		}
	}
	return iSum;
}

int main()
{
    int iValue1 = 0;
    int iValue2 = 0;
    int iRet=0;
	
    printf("Enter first number : \n");
    scanf("%d",&iValue1);
    
	printf("Enter second number : \n");
    scanf("%d",&iValue2);
	
	iRet = RangeSumEven(iValue1, iValue2);     
    
	printf("Summation  is: %d\n",iRet);
		
  return 0;   // return to OS
}











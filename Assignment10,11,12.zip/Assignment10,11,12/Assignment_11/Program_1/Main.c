/*
Problem statement :11.1
 Accept range from user and display all numbers in between that range.  
 
 Input : 1278   Output : 0
 Input : 45228   Output : 2
 Input : 1078   Output : 0
 Input : 22222   Output : 0
 Input : 5379   Output : 1

 */

#include<stdio.h>

/*
 Logical operators :
 1. &&  Logical And         TRUE        TRUE
 2. ||  Logical OR            TRUE        FALSE      /       FALSE       TRUE
 */

void RangeDisplay(int iStart , int iEnd) {
    
	int iCnt = 0;
    
    for(iCnt=iStart;iCnt<=iEnd;iCnt++)
	{
		printf("%d\t",iCnt);
	}
	return iCnt;
	
	
	
}

int main()
{
    int iValue1 = 0;
    int iValue2 = 0;
    
	
    printf("Enter first number : \n");
    scanf("%d",&iValue1);
    
	printf("Enter second number : \n");
    scanf("%d",&iValue2);
	
	RangeDisplay(iValue1, iValue2);     
    
    
    return 0;   // return to OS
}











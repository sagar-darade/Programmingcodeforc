/*
Problem statement :11.3
  Accept  range from user and display all numbers in between that range in reverse order.  
 Input : 1278   Output : 0
 Input : 45228   Output : 2
 Input : 1078   Output : 0
 Input : 22222   Output : 0
 Input : 5379   Output : 1

 */

#include<stdio.h>



int RangeDisplayRev(int iStart , int iEnd) {
    
	int iCnt = 0;
	int iRev=0;
	int iRem=0;
	

   while(iEnd>iStart)
   {
	   printf("Input Invalid");
   }
    for(iCnt=iEnd;iCnt>=iStart;iCnt--)
	{
		
		/*iRem=iCnt%10;
		iRev=iRev*10+iRem;
        //iRev = (iRev * 10)+iCnt;
        iCnt = iCnt / 10;
		*/
		printf("%d\t",iCnt);
	}
	return iRev;
}

int main()
{
    int iValue1 = 0;
    int iValue2 = 0;
	
    printf("Enter first number : \n");
    scanf("%d",&iValue1);
    
	printf("Enter second number : \n");
    scanf("%d",&iValue2);
	
	 RangeDisplayRev(iValue1, iValue2);     
		
  return 0;   // return to OS
}











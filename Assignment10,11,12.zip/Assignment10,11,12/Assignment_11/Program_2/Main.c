/*
Problem statement :11.2
 Accept range from user and display  all even numbers in between that range. .  
 
 Input : 1278   Output : 0
 Input : 45228   Output : 2
 Input : 1078   Output : 0
 Input : 22222   Output : 0
 Input : 5379   Output : 1

 */

#include<stdio.h>



void RangeDisplayEven(int iStart , int iEnd) {
    
	int iCnt = 0;
	int iSum=0;
    
    for(iCnt=iStart;iCnt<=iEnd;iCnt++)
	{
		if(iCnt%2==0)
		{	
			printf("%d\t",iCnt);
		}
	
	}
}

int main()
{
    int iValue1 = 0;
    int iValue2 = 0;
    
	
    printf("Enter first number : \n");
    scanf("%d",&iValue1);
    
	printf("Enter second number : \n");
    scanf("%d",&iValue2);
	
	RangeDisplayEven(iValue1, iValue2);     
    
    
    return 0;   // return to OS
}











/*
Problem statement : 10.2
Accept distance in kilometre and convert it into meter. (1
kilometre = 1000 Meter)

 Input : 1278   Output : 2
 Input : 45228   Output : 1
 Input : 1078   Output : 2
 Input : 22222   Output : 0
 Input : 5379   Output : 4
 
 */

#include<stdio.h>

double SquareMeter(int iNo) 
{
    double iAns;
	//double dSquareFeet= 0.0929;
	
		if(iNo<=0)
		{
			iNo=-iNo;
		}
		//printf("%d",iNo);
		iAns = iNo*0.0929;
    return iAns;
}

int main()
{
   int iValue = 0;
   double dRet = 0; 
    
    printf("Enter number : \n");
    scanf("%d",&iValue);
    
    dRet=SquareMeter(iValue) ;
    
    printf("SquareMeter is : %.4f\n",dRet);
    
    return 0;   // return to OS
}











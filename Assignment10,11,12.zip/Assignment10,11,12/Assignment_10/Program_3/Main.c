/*
Problem statement : 10.2
Accept distance in kilometre and convert it into meter. (1
kilometre = 1000 Meter)

 Input : 1278   Output : 2
 Input : 45228   Output : 1
 Input : 1078   Output : 2
 Input : 22222   Output : 0
 Input : 5379   Output : 4
 
 */

#include<stdio.h>

int KMtoMeter(int iNo) 
{
    int iAns;
	int iMeter=1000;
	
		if(iNo<=0)
		{
			iNo=-iNo;
		}
		iAns = iNo*iMeter;
    
    return iAns;
}

int main()
{
   int iValue = 0;
   int iRet = 0; 
    
    printf("Enter number : \n");
    scanf("%d",&iValue);
    
    iRet=KMtoMeter(iValue) ;
    
    printf("calculate KM TO Meter : %d\n",iRet);
    
    return 0;   // return to OS
}











/*
Problem statement : 10.1
Accept  radius of circle from user and calculate its area.
Consider value of PI as 3.14. (Area = PI * Radius * Radius)  

 Input : 1278   Output : 2
 Input : 45228   Output : 1
 Input : 1078   Output : 2
 Input : 22222   Output : 0
 Input : 5379   Output : 4
 
 */

#include<stdio.h>

double CircleArea(float fRadius) 
{
    float dAns;
	
		if(fRadius<=0)
		{
			fRadius=-fRadius;
		}
    
		dAns = 3.14*fRadius*fRadius;
    
    return dAns;
}

int main()
{
   float fValue = 0.0;
   double dRet = 0.0; 
    
    printf("Enter number : \n");
    scanf("%f",&fValue);
    
    dRet = CircleArea(fValue);
    
    printf("calculate its area : %.4f\n",dRet);
    
    return 0;   // return to OS
}











/*
Problem statement : 10.4
Accept  temperature in Fahrenheit and convert it into
celsius. (1 celsius = (Fahrenheit -32) * (5/9)) 

 Input : 1278   Output : 2
 Input : 45228   Output : 1
 Input : 1078   Output : 2
 Input : 22222   Output : 0
 Input : 5379   Output : 4
 
 */

#include<stdio.h>

double FhtoCs(float fTemp) 
{
    double dAns;
	
		dAns=((fTemp-32)*5/9);
    
    return dAns;
}

int main()
{
   float fValue = 0.0;
   double dRet = 0.0; 
    
    printf("Enter temperature in Fahrenheit :\n");
    scanf("%f",&fValue);
    
    dRet=FhtoCs(fValue);
    
    printf(" Fahrenheit is : %.4f\n",dRet);
    
    return 0;   // return to OS
}











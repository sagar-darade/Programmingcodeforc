/*
Problem statement : 10.1
Accept  width & height of rectangle from user and calculate
its area. (Area = Width * Height)   

 Input : 1278   Output : 2
 Input : 45228   Output : 1
 Input : 1078   Output : 2
 Input : 22222   Output : 0
 Input : 5379   Output : 4
 
 */

#include<stdio.h>

double RectArea(float fWidth, float fHeight) 
{
    float fAns;
	
		if(fWidth<=0) 
		{
			fWidth=-fWidth;
		}
		if(fHeight<=0)
		{
			fHeight=-fHeight;
		}
    
		fAns = fWidth*fHeight;
    
    return fAns;
}

int main()
{
   float fValue1 = 0.0,fValue2 = 0.0;
   double dRet = 0.0; 
    
    printf("Enter Width : \n");
    scanf("%f",&fValue1);
	
	printf("Enter Height : \n");
    scanf("%f",&fValue2);
    
    dRet = RectArea(fValue1,fValue2);
    
    printf("calculate its area : %.4f\n",dRet);
    
    return 0;   // return to OS
}











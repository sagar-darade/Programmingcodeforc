#include "Header.h"

/////////////////////////////////////////////////
//
//Function Name: PrintEven
//Parameters:	 Integer
//Return Value:  Integer
//Descrition:    it is used to print evaen number
//Author:		 Sagar Darade
//Date:			 31/07/2020
//
//////////////////////////////////////////////////
			
			
void PrintEven(int iNo)
{
	int iRest=0;
	
	int iCnt=0;
	
	/*if(iNo<=0)
	{
		return 1;
	}*/
	if(iNo<0)
	{
		iNo=-iNo;
	}
	
		for(iCnt=1;iCnt<=iNo;iCnt++)
		//for(iCnt=2; iCnt<=((iNo+2)*2); iCnt++)
		{
			/*if(iRest<iNo)
			
			{
				if(iCnt%2==0)
				{
					printf("%d\t",iCnt);
					iRest++;
				}
			}*/
			iRest=2*iCnt;
			
			printf("%d\t",iRest);
		}
}
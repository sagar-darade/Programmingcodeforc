#include<stdio.h>

void PrintEven(int);	//Function prototype
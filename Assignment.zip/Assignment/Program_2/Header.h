#include<stdio.h>

void DisplayFactor(int);	//Function prototype
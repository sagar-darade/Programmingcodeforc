#include<stdio.h>

void DisplayConvert(char);	//Function prototype
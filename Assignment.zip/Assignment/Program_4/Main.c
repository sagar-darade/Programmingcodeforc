	#include "Header.h"

/*
Problem Statement:- Accept one character from user and convert case of that character. 
*/




	int main()
	{
		 char cValue = '\0';

		 printf("Enter character\n");
		 scanf("%c",&cValue);
		 DisplayConvert(cValue );
		 return 0;
	} 
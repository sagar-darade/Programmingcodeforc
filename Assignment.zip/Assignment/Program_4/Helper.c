			
			
#include "Header.h"

/////////////////////////////////////////////////
//
//Function Name: DisplayConvert
//Parameters:	 Charcter
//Return Value:  Charcter
//Descrition:    it is used to print Charcter
//Author:		 Sagar Darade
//Date:			 31/07/2020
//
//////////////////////////////////////////////////
			
			
	void DisplayConvert (char CValue)
	{
		if('a'<=ch && ch<='z')
		{
			printf("%c",ch-32);
		}
		else if('A' <= ch && ch <= 'Z')
		{
			printf("%c",ch+32);
		}

	} 
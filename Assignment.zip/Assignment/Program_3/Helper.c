#include "Header.h"

/////////////////////////////////////////////////
//
//Function Name: DisplayFactor
//Parameters:	 Integer
//Return Value:  Integer
//Descrition:    it is used to print evaen number
//Author:		 Sagar Darade
//Date:			 31/07/2020
//
//////////////////////////////////////////////////
			
			
void DisplayFactor(int iNo)
{
	int iRest=0;
	
	int i=0;
	
	if(iNo<=0)
	{
		iNo=-iNo;
	}
	
		for(i=1;i<a;i++)
		{
			if(a%i==0 && i%2==0) 
			{
				
				printf("%d\t",i);
				
			}
		}
}
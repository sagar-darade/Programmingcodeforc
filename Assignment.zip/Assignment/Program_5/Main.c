#include "Header.h"

/*
Problem Statement:- Accept on character from user and check whether that character is vowel
(a,e,i,o,u) or not. 
*/


	int main()
	{
		 char cValue = '\0';
		 BOOL bRet = FALSE;

		 printf("Enter character\n");
		 scanf("%c",&cValue);
		 bRet = ChkVowel(cValue );

		 if (bRet == TRUE)
		 {
			printf("It is Vowel");
		 }
		 else
		 {
			printf("It is not Vowel");
		 }
		 return 0;
	}
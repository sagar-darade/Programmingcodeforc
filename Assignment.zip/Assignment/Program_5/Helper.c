#include "Header.h"

/////////////////////////////////////////////////
//
//Function Name: ChkVowel
//Parameters:	 char
//Return Value:  None
//Descrition:    it is used to check vowel or not 
//Author:		 Sagar Darade
//Date:			 31/07/2020
//
//////////////////////////////////////////////////
			
			
int ChkVowel(char ch)
{
	if(ch=='a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' ||
		ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U')
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

#include<stdio.h>       // Used for IO functions

typedef int BOOLEAN;

#define TRUE 1
#define FALSE 0

BOOLEAN Division(int,int,double *);    // Function prototype

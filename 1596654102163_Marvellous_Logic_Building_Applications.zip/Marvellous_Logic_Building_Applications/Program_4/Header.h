#include<stdio.h>       // Used for IO functions

double Division(int,int);    // Function prototype

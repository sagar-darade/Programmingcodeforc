
#include<stdio.h>       // REquired for printf and scanf

int CountDigits(int);

#include"Header.h"

////////////////////////////////////////////
//	Function Name:	Pattern
//	Input:			integr
//	Output:			$ *
//	Description:	it is used to print number 
//	Author:			Sagar Darade
//	Date:			06-08-2020
//
////////////////////////////////////////////////

void Pattern(int iNo)
{
	int iCnt=0;
	if(iNo<=0)
	{
		iNo=-iNo;
	}
	
	for(iCnt=1;iCnt<=iNo;iCnt++)
	{
		printf("  $  ");
		printf("  *  ");
		
	}
}
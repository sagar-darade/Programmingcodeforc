/*
Problem Statement: Accept  number from user and print that number of $ & *on screen.  
*/
#include "Header.h"

 int main()
 {

	int iValue = 0;
 
	printf("Enter number\n");
	scanf("%d",&iValue);
 
	Pattern(iValue);
 
 return 0;

 }
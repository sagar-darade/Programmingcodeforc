/*
Problem Statement: Accept number from user and print its numbers line. 
*/
#include "Header.h"

 int main()
 {

	int iValue = 0;
 
	printf("Enter number\n");
	scanf("%d",&iValue);
 
	Display(iValue);
 
 return 0;

 }
#include"Header.h"

////////////////////////////////////////////
//	Function Name:	Display
//	Input:			integr
//	Output:			-4 -3 -2 -1 0 1 2 3 4
//	Description:	it is used to print number 
//	Author:			Sagar Darade
//	Date:			06-08-2020
//
////////////////////////////////////////////////

void Display(int iNo)
{
	int iCnt=0;
	int icnt=0;
	
	if(iNo<0)
	{
		for(iCnt=iNo; iCnt<=(-iNo); iCnt++)
		{
			printf(" %d",iCnt);
		}
	}
		else{
		for(iCnt=(-iNo); iCnt<=iNo; iCnt++)
		{
			printf(" %d",iCnt);
		}
	}
	
}
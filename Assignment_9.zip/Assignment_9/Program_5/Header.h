#include<stdio.h>

void MultipleDisplay(int);
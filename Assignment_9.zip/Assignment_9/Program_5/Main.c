/*
Problem Statement: Accept N and print first 5 multiples of N.  
*/
#include "Header.h"

 int main()
 {

	int iValue = 0;
 
	printf("Enter number\n");
	scanf("%d",&iValue);
 
	MultipleDisplay(iValue);
 
 return 0;

 }
#include"Header.h"

////////////////////////////////////////////
//	Function Name:	MultipleDisplay
//	Input:			integr
//	Output:			integr
//	Description:	it is used to print number 
//	Author:			Sagar Darade
//	Date:			06-08-2020
//
////////////////////////////////////////////////

void MultipleDisplay(int iNo)
{
	int iCnt=0;
	int iAns=0;
	
	for(iCnt=1;iCnt<=5;iCnt++)
	{
		iAns=iNo*iCnt;
		
		printf("%d\t",iAns);
	}
	
	
}
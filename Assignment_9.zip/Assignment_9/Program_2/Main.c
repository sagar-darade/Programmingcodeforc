/*
Problem Statement: Accept number from user and print numbers till that number. 
*/
#include "Header.h"

 int main()
 {

	int iValue = 0;
 
	printf("Enter number\n");
	scanf("%d",&iValue);
 
	Display(iValue);
 
 return 0;

 }
#include<stdio.h>

void OddDisplay(int);
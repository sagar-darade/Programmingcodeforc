#include"Header.h"

////////////////////////////////////////////
//	Function Name:	Display
//	Input:			integr
//	Output:			integr
//	Description:	it is used to print number 
//	Author:			Sagar Darade
//	Date:			06-08-2020
//
////////////////////////////////////////////////

void OddDisplay(int iNo)
{
	int iCnt=0;
	
	for(iCnt=1;iCnt<=iNo;iCnt++)
	{
		if(iCnt%2!=0)
		{
			printf("%d\t",iCnt);
		}
	}
	
	
}
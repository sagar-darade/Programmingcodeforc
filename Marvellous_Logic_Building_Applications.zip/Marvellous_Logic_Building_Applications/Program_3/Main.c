/*
 Problem statement : Write a program which display 1 to 5 on screen.
 */

#include "Header.h"

int main()      // Entry point function
{
    printf("Inside main function...\n");
    
    DisplayNumberX();
    
    return 0;
}

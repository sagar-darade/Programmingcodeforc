#include<stdio.h>

void DisplayNumber();

void DisplayNumberX();

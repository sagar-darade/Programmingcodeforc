
#include<stdio.h>       // REquired for printf and scanf

typedef int BOOL;

#define TRUE 1
#define FALSE 0

BOOL CheckPerfect(int);

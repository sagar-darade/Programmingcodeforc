#include "Header.h"

/*
Problem Statement:-Accept one number from user and check whether that
number is greater than 100 or not. 
*/

/*
 
	Algorithim
		
		
	START
		
		Accept first number as iValue1
        
       
        Create one variable as result
 
        Perform check the no is greater than 100 or not
		if no is greater
	
		Then return greater
            Otherwise
                Return not gra
	
        return the value from result	
				
	END
	
*/

int main()
{
	int iValue = 0;
	BOOL bRet=FALSE;
	
	
	printf("Enter number\n");
	scanf("%d",&iValue);
 
	bRet=ChkGreater(iValue);
	
	if(bRet==TRUE)
	{
		printf("Number is Greater");
	}
	else
	{
		printf("Number is Smaller");	
	}
  return 0;
} 
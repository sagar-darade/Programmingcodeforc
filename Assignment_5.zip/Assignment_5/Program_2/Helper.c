			
			
#include "Header.h"

/////////////////////////////////////////////////
//
//Function Name: ChkGreater
//Input:	     Integer
//Return Value:  None
//Descrition:    it is used to check no is greater or not
//Author:		 Sagar Darade
//Date:			 04/07/2020
//
//////////////////////////////////////////////////
			
BOOL ChkGreater(iNO)
{

	
	if(iNO>100)
	{
		return TRUE;
	}	
	else 
	{
		return FALSE;
	}
	
	
	
	return iNO;
}			
	
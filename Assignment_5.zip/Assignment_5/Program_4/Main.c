#include"Header.h"
/*
Problem Statement: Accpet three numbers and print its multiplication. 
*/

/*
Algorithim:

	START
		
		Accept first number as iValue1
		Accept second number as iValue2
		Accept third number as iValue3
		
		create local variable store the result
		
		Perform multiplication of iValue1 * iValue2 * iValue3
        Store the result in ans
 
        return the value from ans	
		
	
	END
*/

int main()
{
	int iValue1=0,iValue2=0,iValue3=0;
	int iRet=0;
	
	printf("Enter first number\n");
	scanf("%d",&iValue1);
	
	printf("Enter second number\n");
	scanf("%d",&iValue2);
	
	printf("Enter third number\n");
	scanf("%d",&iValue3);
	
	iRet= Multiply(iValue1,iValue2,iValue3);
	
	printf("Multiplicaton is : %d\n",iRet);

	return 0;
}
#include"Header.h"

//////////////////////////////////////////////////////////
//
// Function Name:Multiply
// Input :integer
// Output:integer
// Description: it is used to perfrom multiplication.
// Author:Sagar Darade
// Date:04/08/2020
//
/////////////////////////////////////////////////////////

int Multiply(iNo1,iNo2,iNo3)
{
	int iResult=0;
	
	if(iNo1 == 0 || iNo2 == 0 || iNo3 == 0  )
	{
		return 0;
	}
	else
	if(iNo1 == 1 || iNo2 == 0 || iNo3 == 0  )
	{
		return 0;
	}
	
	iResult=iNo1*iNo2*iNo3;
	
	return iResult;
	
}
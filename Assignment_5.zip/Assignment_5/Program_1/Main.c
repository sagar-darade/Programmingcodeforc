

/*
Problem Statement:- Accept name from user and print that number. 
*/

#include<stdio.h>

int main()
{
	char Name[40];
	
	printf("Enter The Name\n");
	scanf("%s",&Name);
	
	printf("Your Name is: %s",Name);
	
	return 0;
}
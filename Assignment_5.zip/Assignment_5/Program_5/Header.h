#include<stdio.h>

float Percentage(int,int); //Function Prototype
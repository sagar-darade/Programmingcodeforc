#include"Header.h"

//////////////////////////////////////////////////////
//
//	Function Name:Percentage
//	Integer:		integer 
//	Output:			float
//	Description:	it is used to the calculte percentage
//	Author:			Sagar Darade
//	Date:			04/08/2020
//
/////////////////////////////////////////////////////////

float Percentage(iNo1,iNo2)
{
	float iAns=0;
	
	if(iNo1 == 0 ||	iNo2 == 0)
	{
		printf("Please Enter Valid Input\n ");
		//return 0;
	}
	
		iAns=(float)iNo2/(float)iNo1	*100;
	
	return iAns;
	
}
#include "Header.h"

/*
	Problem Statement:- Accept two numbers total marks & obtained marks from user and calculate percentage. 
*/

/*
Algorithim:

	START
	
		Accept first number as iValue1
		Accept second number as iValue2
		
			craete variable store the ans
		
			obtained marks divide by total marks (no1/no2)*100 multiply by 100
				
				store the percentage is ans
					
			return ans		
		
	
	END
*/

int main()
{
	int iValue1=0,iValue2=0;
	float fRet=0.0;
	
	printf("Please enter total marks\n");
	scanf("%d",&iValue1);
	
	printf("Please enter obtained marks\n");
	scanf("%d",&iValue2);
	
	fRet= Percentage(iValue1,iValue2);
	
	printf("Percentage = %.2f%%",fRet);
	
	return 0;
}
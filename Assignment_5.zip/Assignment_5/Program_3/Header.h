#include<stdio.h>

typedef int BOOL;

#define TRUE 0
#define FALSE 1

BOOL ChkEqual(int,int); //Function Prototype
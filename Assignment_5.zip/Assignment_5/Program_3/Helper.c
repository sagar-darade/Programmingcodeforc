#include"Header.h"

///////////////////////////////////////////////////////////////
//
// Function Name:	ChkEqual
// Input:			integer
// Output:			None
// Description:	 	It is used to perform number is equal or not 
// Author:			Sagar Darade
// Date:			04/07/2020
//
////////////////////////////////////////////////////////////////

BOOL ChkEqual(iNo1,iNo2)
{
	if(iNo1==iNo2)
	{
		return 0;
	}
	else
	{
		return 1;
	}	
}
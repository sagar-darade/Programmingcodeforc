#include"Header.h"

/*
Problem Statement:- Accept two no from user and check whether numbers are equal or not. 
*/

/*Algorithim

	START
	
		Accept first number as iValue1
		Accept first number as iValue2
				
		Create one variable as result
 
        Perform check the no is equal or not
		if no is equal
	
		Then return equal
            Otherwise
                Return not equal
	
        return the value from result	
				
	END

*/

int main() 			//Entry point Finction
{
	int iValue1=0,iValue2=0;
	BOOL bRet=FALSE;
	
	printf("Enetr first No\n");
	scanf("%d",&iValue1);
	
	printf("Enter Second No\n");
	scanf("%d",&iValue2);
	
	bRet=ChkEqual(iValue1,iValue2);
	
	if(bRet==TRUE)
	{
		printf("Number is equal\n");
	}
	else
	{
		printf("Number is not equal\n");
	}
	
	return 0;
}